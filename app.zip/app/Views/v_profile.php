<?= $this->extend('layout') ?>
<?= $this->section('content') ?>
Ini halaman Profile
<?= $this->endSection() ?>